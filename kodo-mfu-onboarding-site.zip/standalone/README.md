# KodoNorth MFU onboarding

A static web page that helps a customer fill the three MF Utilities onboarding documents:

- CAN Registration Form (`crf.pdf`)
- Login Access Request Form (`login.pdf`)
- Board Resolution and Authorised Signatory List (`br-template.b64.txt`, a base64 Word template)

All form filling happens in the visitor's browser. The site has no backend and no server sends or stores anything. Answers are kept in the visitor's browser storage so they can come back later on the same device.

## Files

| File | Purpose |
| --- | --- |
| `index.html` | The whole app (UI, validation, PDF and Word filling) |
| `crf.pdf`, `login.pdf` | Blank MFU templates the app writes onto |
| `br-template.b64.txt` | Board resolution Word template, base64 encoded |
| `vendor/` | pdf-lib 1.17.1 and JSZip 3.10.1 |
| `CNAME` | Custom domain for GitHub Pages. Change it or delete it |
| `.nojekyll` | Tells GitHub Pages to serve files as they are |

## Run locally

```
python3 -m http.server 8000
```

Open http://localhost:8000. The page must be served over HTTP; opening `index.html` directly from disk will not load the templates.

## Deploy on GitHub Pages with a Kodo domain

1. Create a repository (for example `kodo/mfu-onboarding`) and push this folder to the `main` branch.
2. In the repository, go to **Settings → Pages**, set **Source** to "Deploy from a branch", branch `main`, folder `/ (root)`.
3. Edit `CNAME` to the subdomain you want (it currently says `onboarding.kodo.com`).
4. In Kodo's DNS, add a `CNAME` record for that subdomain pointing to `<your-org>.github.io`.
5. Back in **Settings → Pages**, wait for the DNS check and turn on **Enforce HTTPS**.

GitHub Pages on a free or Team plan serves only public repositories. The blank MFU templates and this code would then be visible on GitHub. On GitHub Enterprise Cloud, Pages can be published from a private repository.

Any static host (Vercel, Netlify, Cloudflare Pages, an S3 bucket behind CloudFront) also works: upload the folder as-is.

## Updating the form geometry

Box positions for the CAN form are in the `BX` constant near the top of the script in `index.html`, in PDF points measured from the top-left of each page. If MFU publishes a new version of a form, replace the PDF and re-measure those positions.
